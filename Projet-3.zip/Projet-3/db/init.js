/**
 * Script d'initialisation de la base de données.
 * Exécute schema.sql puis met à jour les mots de passe des comptes démo
 * avec un vrai hash bcrypt de "password123".
 *
 * Usage: npm run init-db
 */
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

async function main() {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    multipleStatements: true,
  });

  console.log('→ Connexion MySQL OK');

  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  await conn.query(sql);
  console.log('→ Schéma et données créés');

  // Met à jour les mots de passe démo avec un vrai hash bcrypt
  const hash = await bcrypt.hash('password123', 10);
  await conn.query(`USE ${process.env.DB_NAME || 'afrovibe'}`);
  await conn.query('UPDATE users SET password = ?', [hash]);
  console.log('→ Mots de passe démo hashés (password123)');

  await conn.end();
  console.log('\n✅ Base de données initialisée avec succès.');
  console.log('   Comptes de démo :');
  console.log('   - admin@afrovibe.com   / password123  (admin)');
  console.log('   - awa@afrovibe.com     / password123  (organisateur)');
  console.log('   - moussa@afrovibe.com  / password123  (participant)');
}

main().catch((e) => {
  console.error('❌ Erreur init-db:', e.message);
  process.exit(1);
});
