-- ============================================================
-- AfroVibe - Schéma de base de données MySQL
-- ============================================================
DROP DATABASE IF EXISTS afrovibe;
CREATE DATABASE afrovibe CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE afrovibe;

-- Utilisateurs
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100) NOT NULL,
  prenom VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  telephone VARCHAR(30),
  role ENUM('admin','organisateur','participant') NOT NULL DEFAULT 'participant',
  avatar VARCHAR(255),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Catégories
CREATE TABLE categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100) NOT NULL UNIQUE,
  description TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Événements
CREATE TABLE events (
  id INT AUTO_INCREMENT PRIMARY KEY,
  organisateur_id INT NOT NULL,
  categorie_id INT,
  titre VARCHAR(200) NOT NULL,
  description TEXT NOT NULL,
  image VARCHAR(500),
  date_event DATE NOT NULL,
  heure_event TIME NOT NULL,
  ville VARCHAR(100) NOT NULL,
  pays VARCHAR(100) NOT NULL,
  adresse VARCHAR(255) NOT NULL,
  prix DECIMAL(10,2) NOT NULL DEFAULT 0,
  places_totales INT NOT NULL DEFAULT 100,
  places_restantes INT NOT NULL DEFAULT 100,
  statut ENUM('brouillon','en_attente','publie','refuse') DEFAULT 'brouillon',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (organisateur_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (categorie_id) REFERENCES categories(id) ON DELETE SET NULL,
  INDEX idx_ville (ville),
  INDEX idx_pays (pays),
  INDEX idx_date (date_event),
  INDEX idx_statut (statut)
) ENGINE=InnoDB;

-- Réservations
CREATE TABLE reservations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  event_id INT NOT NULL,
  nb_places INT NOT NULL CHECK (nb_places BETWEEN 1 AND 10),
  montant_total DECIMAL(10,2) NOT NULL,
  statut ENUM('en_attente','confirmee','annulee') DEFAULT 'confirmee',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Billets (un billet par place réservée)
CREATE TABLE tickets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  reservation_id INT NOT NULL,
  numero_unique VARCHAR(64) NOT NULL UNIQUE,
  qr_code LONGTEXT,
  utilise BOOLEAN DEFAULT FALSE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (reservation_id) REFERENCES reservations(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Paiements (démo)
CREATE TABLE payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  reservation_id INT NOT NULL,
  montant DECIMAL(10,2) NOT NULL,
  methode VARCHAR(50) DEFAULT 'demo',
  statut ENUM('reussi','echoue') DEFAULT 'reussi',
  reference VARCHAR(100),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (reservation_id) REFERENCES reservations(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Notifications
CREATE TABLE notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  titre VARCHAR(150) NOT NULL,
  message TEXT NOT NULL,
  lu BOOLEAN DEFAULT FALSE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Avis
CREATE TABLE avis (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  event_id INT NOT NULL,
  note INT NOT NULL CHECK (note BETWEEN 1 AND 5),
  commentaire TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
  UNIQUE KEY unique_avis (user_id, event_id)
) ENGINE=InnoDB;

-- ============================================================
-- Données de démonstration
-- ============================================================

-- Catégories
INSERT INTO categories (nom, description) VALUES
('Concert', 'Concerts et spectacles musicaux'),
('Festival', 'Festivals culturels et musicaux'),
('Conférence', 'Conférences et séminaires'),
('Sport', 'Événements sportifs et matchs'),
('Formation', 'Ateliers et formations'),
('Foire', 'Foires et expositions');

-- Utilisateurs (mot de passe pour tous: "password123" haché avec bcrypt)
-- Hash bcrypt de "password123": $2a$10$Zc4z8Y6t2ZlY4Nq5X6mE2eO7YyQpZ3lF9j6t.vB7pR9Fq4KzX9jGe
INSERT INTO users (nom, prenom, email, password, telephone, role) VALUES
('Admin', 'AfroVibe', 'admin@afrovibe.com', '$2a$10$Zc4z8Y6t2ZlY4Nq5X6mE2eO7YyQpZ3lF9j6t.vB7pR9Fq4KzX9jGe', '+221770000000', 'admin'),
('Diop', 'Awa', 'awa@afrovibe.com', '$2a$10$Zc4z8Y6t2ZlY4Nq5X6mE2eO7YyQpZ3lF9j6t.vB7pR9Fq4KzX9jGe', '+221771111111', 'organisateur'),
('Traoré', 'Moussa', 'moussa@afrovibe.com', '$2a$10$Zc4z8Y6t2ZlY4Nq5X6mE2eO7YyQpZ3lF9j6t.vB7pR9Fq4KzX9jGe', '+221772222222', 'participant');
